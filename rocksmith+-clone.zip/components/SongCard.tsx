
import React from 'react';
import type { Song } from '../types';
import { PlayIcon } from './icons';

interface SongCardProps {
  song: Song;
  onPlay: (song: Song) => void;
}

const difficultyColorMap = {
    'Beginner': 'bg-green-500',
    'Intermediate': 'bg-blue-500',
    'Advanced': 'bg-yellow-500',
    'Master': 'bg-red-500',
}

const SongCard: React.FC<SongCardProps> = ({ song, onPlay }) => {
  return (
    <div className="group relative rounded-lg overflow-hidden bg-gray-800 hover:bg-gray-700 transition-all duration-300 cursor-pointer shadow-lg" onClick={() => onPlay(song)}>
      <img src={song.albumArt} alt={`${song.title} album art`} className="w-full h-48 object-cover group-hover:opacity-50 transition-opacity duration-300" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
      
      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="bg-indigo-600 rounded-full p-4 shadow-lg shadow-indigo-600/50">
            <PlayIcon className="w-8 h-8 text-white"/>
        </div>
      </div>
      
      <div className="p-4 relative">
        <div className={`absolute top-0 right-4 -mt-2 px-2 py-1 text-xs font-bold text-white rounded-full ${difficultyColorMap[song.difficulty]}`}>
            {song.difficulty}
        </div>
        <h3 className="font-bold text-lg truncate text-white">{song.title}</h3>
        <p className="text-sm text-gray-400">{song.artist}</p>
      </div>
    </div>
  );
};

export default SongCard;
