
import React from 'react';
import type { Lesson } from '../types';
import { PlayIcon } from './icons';

interface LessonCardProps {
  lesson: Lesson;
}

const LessonCard: React.FC<LessonCardProps> = ({ lesson }) => {
  return (
    <div className="group relative rounded-lg overflow-hidden bg-gray-800 hover:bg-gray-700 transition-all duration-300 cursor-pointer shadow-lg">
      <img src={lesson.thumbnail} alt={`${lesson.title} thumbnail`} className="w-full h-40 object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>

      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="bg-indigo-600 rounded-full p-3 shadow-lg shadow-indigo-600/50">
            <PlayIcon className="w-6 h-6 text-white"/>
        </div>
      </div>
      
      <div className="p-4 relative">
        <span className="text-xs font-semibold text-indigo-400 uppercase">{lesson.category}</span>
        <h3 className="font-bold text-md truncate text-white mt-1">{lesson.title}</h3>
        <p className="text-sm text-gray-400">{lesson.duration} min</p>
      </div>
    </div>
  );
};

export default LessonCard;
