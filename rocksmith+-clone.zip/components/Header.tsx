
import React from 'react';
import { UserCircleIcon } from './icons';

interface HeaderProps {
  title: string;
  subtitle?: string;
}

const Header: React.FC<HeaderProps> = ({ title, subtitle }) => {
  return (
    <div className="flex justify-between items-center mb-8">
      <div>
        <h1 className="text-4xl font-black tracking-tight">{title}</h1>
        {subtitle && <p className="text-gray-400 mt-1">{subtitle}</p>}
      </div>
      <div className="flex items-center space-x-4">
        <span className="font-semibold text-gray-300">User</span>
        <UserCircleIcon className="w-10 h-10 text-gray-500" />
      </div>
    </div>
  );
};

export default Header;
