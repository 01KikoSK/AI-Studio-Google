
import React from 'react';
import type { Page } from '../types';
import { HomeIcon, MusicNoteIcon, BookOpenIcon, WrenchScrewdriverIcon } from './icons';

interface SidebarProps {
  currentPage: Page;
  navigate: (page: Page) => void;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-4 w-full text-left p-3 rounded-lg transition-all duration-200 ${
      isActive
        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
        : 'text-gray-400 hover:bg-gray-700/50 hover:text-white'
    }`}
  >
    {icon}
    <span className="font-semibold">{label}</span>
  </button>
);

const Sidebar: React.FC<SidebarProps> = ({ currentPage, navigate }) => {
  return (
    <aside className="w-64 bg-gray-800/50 border-r border-gray-700/50 p-6 flex-shrink-0 flex flex-col justify-between">
      <div>
        <div className="flex items-center space-x-3 mb-10">
            <MusicNoteIcon className="w-8 h-8 text-indigo-400" />
            <h1 className="text-2xl font-bold tracking-tighter">
                Rocksmith<span className="text-indigo-400">+</span>
            </h1>
        </div>
        <nav className="space-y-2">
            <NavItem
                icon={<HomeIcon />}
                label="Home"
                isActive={currentPage === 'home'}
                onClick={() => navigate('home')}
            />
            <NavItem
                icon={<MusicNoteIcon />}
                label="Songs"
                isActive={currentPage === 'songs'}
                onClick={() => navigate('songs')}
            />
            <NavItem
                icon={<BookOpenIcon />}
                label="Lessons"
                isActive={currentPage === 'lessons'}
                onClick={() => navigate('lessons')}
            />
            <NavItem
                icon={<WrenchScrewdriverIcon />}
                label="Tools"
                isActive={currentPage === 'tools'}
                onClick={() => navigate('tools')}
            />
        </nav>
      </div>
      <div className="text-center text-xs text-gray-500">
        <p>Rocksmith+ Clone v1.0</p>
        <p>For educational purposes only.</p>
      </div>
    </aside>
  );
};

export default Sidebar;
