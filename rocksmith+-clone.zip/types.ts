
export interface Song {
  id: number;
  title: string;
  artist: string;
  albumArt: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Master';
  tuning: string;
  year: number;
}

export interface Lesson {
  id: number;
  title: string;
  category: string;
  duration: number; // in minutes
  thumbnail: string;
}

export type Page = 'home' | 'songs' | 'lessons' | 'tools' | 'player';
