
import React, { useState, useCallback } from 'react';
import type { Page, Song } from './types';
import Sidebar from './components/Sidebar';
import HomePage from './pages/HomePage';
import SongLibraryPage from './pages/SongLibraryPage';
import LessonsPage from './pages/LessonsPage';
import ToolsPage from './pages/ToolsPage';
import PlayerPage from './pages/PlayerPage';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [activeSong, setActiveSong] = useState<Song | null>(null);
  const [previousPage, setPreviousPage] = useState<Page>('home');

  const navigate = useCallback((page: Page) => {
    if (page !== 'player') {
      setPreviousPage(currentPage);
    }
    setCurrentPage(page);
  }, [currentPage]);

  const playSong = useCallback((song: Song) => {
    setPreviousPage(currentPage);
    setActiveSong(song);
    setCurrentPage('player');
  }, [currentPage]);

  const exitPlayer = useCallback(() => {
    setActiveSong(null);
    setCurrentPage(previousPage);
  }, [previousPage]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onPlaySong={playSong} />;
      case 'songs':
        return <SongLibraryPage onPlaySong={playSong} />;
      case 'lessons':
        return <LessonsPage />;
      case 'tools':
        return <ToolsPage />;
      case 'player':
        return activeSong ? <PlayerPage song={activeSong} onExit={exitPlayer} /> : <HomePage onPlaySong={playSong} />;
      default:
        return <HomePage onPlaySong={playSong} />;
    }
  };

  return (
    <div className="bg-gray-900 text-white min-h-screen flex selection:bg-indigo-500 selection:text-white">
      <Sidebar currentPage={currentPage} navigate={navigate} />
      <main className="flex-1 overflow-y-auto">
        {renderPage()}
      </main>
    </div>
  );
};

export default App;
