
import React, { useState } from 'react';
import Header from '../components/Header';
import SongCard from '../components/SongCard';
import { SONGS } from '../constants';
import type { Song } from '../types';

interface SongLibraryPageProps {
  onPlaySong: (song: Song) => void;
}

const SongLibraryPage: React.FC<SongLibraryPageProps> = ({ onPlaySong }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [difficultyFilter, setDifficultyFilter] = useState('All');

    const filteredSongs = SONGS.filter(song => {
        const matchesSearch = song.title.toLowerCase().includes(searchTerm.toLowerCase()) || song.artist.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesDifficulty = difficultyFilter === 'All' || song.difficulty === difficultyFilter;
        return matchesSearch && matchesDifficulty;
    });

    const difficulties = ['All', 'Beginner', 'Intermediate', 'Advanced', 'Master'];

    return (
        <div className="p-8">
            <Header title="Song Library" subtitle="Find your next challenge."/>

            <div className="mb-8 flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
                <input
                    type="text"
                    placeholder="Search by song or artist..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="flex-grow bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
                <div className="flex items-center space-x-2 bg-gray-800 border border-gray-700 rounded-lg p-1">
                    {difficulties.map(diff => (
                        <button
                            key={diff}
                            onClick={() => setDifficultyFilter(diff)}
                            className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors duration-200 ${
                                difficultyFilter === diff ? 'bg-indigo-600 text-white' : 'text-gray-300 hover:bg-gray-700'
                            }`}
                        >
                            {diff}
                        </button>
                    ))}
                </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {filteredSongs.map(song => (
                    <SongCard key={song.id} song={song} onPlay={onPlaySong} />
                ))}
            </div>
             {filteredSongs.length === 0 && (
                <div className="text-center py-16 col-span-full">
                    <p className="text-gray-400 text-lg">No songs match your criteria.</p>
                </div>
            )}
        </div>
    );
};

export default SongLibraryPage;
