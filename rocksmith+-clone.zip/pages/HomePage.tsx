
import React from 'react';
import Header from '../components/Header';
import SongCard from '../components/SongCard';
import LessonCard from '../components/LessonCard';
import { SONGS, LESSONS } from '../constants';
import type { Song } from '../types';

interface HomePageProps {
  onPlaySong: (song: Song) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onPlaySong }) => {
  const newSongs = SONGS.slice(0, 4);
  const continueLearning = LESSONS.slice(0, 3);
  const recommendations = SONGS.slice(4, 8);

  return (
    <div className="p-8">
      <Header title="Welcome Back!" subtitle="Let's make some noise."/>
      
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-4 text-indigo-300">What's New</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {newSongs.map(song => <SongCard key={song.id} song={song} onPlay={onPlaySong} />)}
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-4 text-indigo-300">Continue Learning</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {continueLearning.map(lesson => <LessonCard key={lesson.id} lesson={lesson} />)}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-4 text-indigo-300">Recommended For You</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {recommendations.map(song => <SongCard key={song.id} song={song} onPlay={onPlaySong} />)}
        </div>
      </section>
    </div>
  );
};

export default HomePage;
