
import React from 'react';
import type { Song } from '../types';
import { ChevronLeftIcon, PlayIcon } from '../components/icons';

interface PlayerPageProps {
  song: Song;
  onExit: () => void;
}

const NoteHighway: React.FC = () => {
    // This component creates a visual representation of the note highway
    return (
        <div className="absolute inset-0 overflow-hidden" style={{ perspective: '100px' }}>
            <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-gray-900 to-indigo-900/30"></div>
            <div 
                className="absolute w-full h-full bg-repeat-y" 
                style={{ 
                    backgroundImage: 'linear-gradient(rgba(129, 140, 248, 0.2) 1px, transparent 1px)',
                    backgroundSize: '100% 50px',
                    animation: 'scroll-bg 2s linear infinite'
                }}
            ></div>
            <div 
                className="absolute w-full h-full"
                style={{ 
                    transform: 'rotateX(20deg) scale(2.5) translateY(-20%)',
                    transformOrigin: 'top center',
                }}
            >
                {/* Fret markers */}
                <div className="absolute h-full w-px bg-indigo-400/50" style={{ left: '20%' }}></div>
                <div className="absolute h-full w-px bg-indigo-400/50" style={{ left: '35%' }}></div>
                <div className="absolute h-full w-px bg-indigo-400/50" style={{ left: '50%' }}></div>
                <div className="absolute h-full w-px bg-indigo-400/50" style={{ left: '65%' }}></div>
                <div className="absolute h-full w-px bg-indigo-400/50" style={{ left: '80%' }}></div>
            </div>
            <style>
                {`@keyframes scroll-bg { from { background-position-y: 0; } to { background-position-y: 50px; } }`}
            </style>
        </div>
    );
};

const PlayerPage: React.FC<PlayerPageProps> = ({ song, onExit }) => {
    return (
        <div className="h-screen w-full flex flex-col bg-black relative">
            <NoteHighway />

            {/* UI Overlay */}
            <div className="absolute inset-0 flex flex-col justify-between p-6 z-10">
                {/* Top Bar */}
                <div className="flex justify-between items-start">
                    <button onClick={onExit} className="flex items-center space-x-2 bg-black/50 backdrop-blur-sm p-2 rounded-lg hover:bg-white/20 transition-colors">
                        <ChevronLeftIcon className="w-6 h-6" />
                        <span className="font-semibold">Back to Library</span>
                    </button>
                    <div className="text-right bg-black/50 backdrop-blur-sm p-3 rounded-lg">
                        <h2 className="text-3xl font-bold">{song.title}</h2>
                        <p className="text-xl text-gray-300">{song.artist}</p>
                    </div>
                </div>

                {/* Center Score */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center space-y-2 text-center">
                    <div className="text-7xl font-black text-white" style={{ textShadow: '0 0 15px rgba(255,255,255,0.7)'}}>100%</div>
                    <div className="text-2xl font-bold text-yellow-400">Perfect</div>
                </div>

                {/* Bottom Bar */}
                <div className="flex flex-col items-center">
                    {/* Progress Bar */}
                    <div className="w-full max-w-4xl mb-4">
                        <div className="flex justify-between text-sm font-semibold mb-1">
                            <span>1:23</span>
                            <span>3:45</span>
                        </div>
                        <div className="w-full bg-gray-700/50 rounded-full h-2.5">
                            <div className="bg-indigo-500 h-2.5 rounded-full" style={{ width: '45%' }}></div>
                        </div>
                    </div>

                    {/* Controls */}
                    <div className="flex items-center space-x-6 bg-black/50 backdrop-blur-sm p-4 rounded-full">
                        <p className="font-semibold text-lg">Score: <span className="text-indigo-400">1,234,567</span></p>
                        <button className="bg-indigo-600 rounded-full p-4 hover:bg-indigo-500 transition-colors shadow-lg shadow-indigo-500/50">
                            <PlayIcon className="w-8 h-8"/>
                        </button>
                        <p className="font-semibold text-lg">Multiplier: <span className="text-yellow-400">x10</span></p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PlayerPage;
