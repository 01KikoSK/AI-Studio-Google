
import React from 'react';
import Header from '../components/Header';
import LessonCard from '../components/LessonCard';
import { LESSONS } from '../constants';

const LessonsPage: React.FC = () => {
  const categories = [...new Set(LESSONS.map(lesson => lesson.category))];

  return (
    <div className="p-8">
      <Header title="Lessons" subtitle="Hone your skills and master techniques."/>

      {categories.map(category => (
        <section key={category} className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-indigo-300">{category}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {LESSONS.filter(lesson => lesson.category === category).map(lesson => (
              <LessonCard key={lesson.id} lesson={lesson} />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
};

export default LessonsPage;
