
import React, { useState } from 'react';
import Header from '../components/Header';

const Tuner: React.FC = () => {
    const strings = ['E', 'A', 'D', 'G', 'B', 'e'];
    const [activeString, setActiveString] = useState('E');

    return (
        <div className="bg-gray-800 rounded-lg p-6 flex flex-col items-center shadow-2xl">
            <h3 className="text-xl font-bold mb-4">Chromatic Tuner</h3>
            <div className="relative w-64 h-32 flex items-center justify-center mb-4">
                <div className="absolute w-full h-1 bg-gray-600 rounded-full"></div>
                <div className="absolute w-1 h-8 bg-indigo-400 top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2"></div>
                <div
                    className="absolute w-0.5 h-24 bg-red-500 origin-bottom transition-transform duration-300 ease-in-out"
                    style={{ transform: `translateX(-50%) rotate(-10deg)` }}
                ></div>
                <div className="text-5xl font-black z-10 text-green-400">{activeString}</div>
            </div>
            <p className="text-lg font-semibold text-green-400 mb-6">In Tune</p>
            <div className="flex space-x-2">
                {strings.map(str => (
                    <button
                        key={str}
                        onClick={() => setActiveString(str)}
                        className={`w-10 h-10 rounded-full font-bold text-lg transition-colors duration-200 flex items-center justify-center ${
                            activeString === str ? 'bg-indigo-600 text-white shadow-lg' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                        }`}
                    >
                        {str}
                    </button>
                ))}
            </div>
        </div>
    );
};

const Metronome: React.FC = () => {
    const [bpm, setBpm] = useState(120);

    return (
        <div className="bg-gray-800 rounded-lg p-6 flex flex-col items-center shadow-2xl">
            <h3 className="text-xl font-bold mb-4">Metronome</h3>
            <div className="text-7xl font-black tracking-tighter mb-4">{bpm}</div>
            <p className="text-sm text-gray-400 mb-6">Beats Per Minute</p>
            <div className="flex items-center space-x-4">
                <button onClick={() => setBpm(b => Math.max(40, b - 5))} className="w-12 h-12 rounded-full bg-gray-700 text-2xl font-bold hover:bg-gray-600 transition-colors">-</button>
                <button className="px-6 py-2 rounded-lg bg-indigo-600 font-semibold hover:bg-indigo-500 transition-colors">Start</button>
                <button onClick={() => setBpm(b => Math.min(240, b + 5))} className="w-12 h-12 rounded-full bg-gray-700 text-2xl font-bold hover:bg-gray-600 transition-colors">+</button>
            </div>
        </div>
    );
};

const ToolsPage: React.FC = () => {
  return (
    <div className="p-8">
      <Header title="Tools" subtitle="Fine-tune your setup and practice."/>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
        <Tuner />
        <Metronome />
      </div>
    </div>
  );
};

export default ToolsPage;
