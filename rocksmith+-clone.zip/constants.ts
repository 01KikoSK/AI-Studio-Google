
import type { Song, Lesson } from './types';

export const SONGS: Song[] = [
  { id: 1, title: "Bohemian Rhapsody", artist: "Queen", albumArt: "https://picsum.photos/seed/bohemian/300/300", difficulty: 'Master', tuning: 'E Standard', year: 1975 },
  { id: 2, title: "Stairway to Heaven", artist: "Led Zeppelin", albumArt: "https://picsum.photos/seed/stairway/300/300", difficulty: 'Advanced', tuning: 'E Standard', year: 1971 },
  { id: 3, title: "Smells Like Teen Spirit", artist: "Nirvana", albumArt: "https://picsum.photos/seed/nirvana/300/300", difficulty: 'Intermediate', tuning: 'E Standard', year: 1991 },
  { id: 4, title: "Come As You Are", artist: "Nirvana", albumArt: "https://picsum.photos/seed/comeas/300/300", difficulty: 'Beginner', tuning: 'Drop D', year: 1991 },
  { id: 5, title: "Back in Black", artist: "AC/DC", albumArt: "https://picsum.photos/seed/acdc/300/300", difficulty: 'Intermediate', tuning: 'E Standard', year: 1980 },
  { id: 6, title: "Sweet Child o' Mine", artist: "Guns N' Roses", albumArt: "https://picsum.photos/seed/guns/300/300", difficulty: 'Advanced', tuning: 'Eb Standard', year: 1987 },
  { id: 7, title: "Enter Sandman", artist: "Metallica", albumArt: "https://picsum.photos/seed/metallica/300/300", difficulty: 'Intermediate', tuning: 'E Standard', year: 1991 },
  { id: 8, title: "Master of Puppets", artist: "Metallica", albumArt: "https://picsum.photos/seed/puppets/300/300", difficulty: 'Master', tuning: 'E Standard', year: 1986 },
  { id: 9, title: "Hotel California", artist: "Eagles", albumArt: "https://picsum.photos/seed/eagles/300/300", difficulty: 'Advanced', tuning: 'E Standard', year: 1976 },
  { id: 10, title: "Seven Nation Army", artist: "The White Stripes", albumArt: "https://picsum.photos/seed/stripes/300/300", difficulty: 'Beginner', tuning: 'E Standard', year: 2003 },
  { id: 11, title: "Paranoid Android", artist: "Radiohead", albumArt: "https://picsum.photos/seed/radiohead/300/300", difficulty: 'Master', tuning: 'E Standard', year: 1997 },
  { id: 12, title: "Iron Man", artist: "Black Sabbath", albumArt: "https://picsum.photos/seed/sabbath/300/300", difficulty: 'Beginner', tuning: 'E Standard', year: 1970 },
];

export const LESSONS: Lesson[] = [
  { id: 1, title: "Basic Fretting", category: "Fundamentals", duration: 10, thumbnail: "https://picsum.photos/seed/lesson1/400/225" },
  { id: 2, title: "String Bending 101", category: "Technique", duration: 15, thumbnail: "https://picsum.photos/seed/lesson2/400/225" },
  { id: 3, title: "Introduction to Power Chords", category: "Chords", duration: 12, thumbnail: "https://picsum.photos/seed/lesson3/400/225" },
  { id: 4, title: "Hammer-ons & Pull-offs", category: "Technique", duration: 18, thumbnail: "https://picsum.photos/seed/lesson4/400/225" },
  { id: 5, title: "The Minor Pentatonic Scale", category: "Scales & Theory", duration: 20, thumbnail: "https://picsum.photos/seed/lesson5/400/225" },
  { id: 6, title: "Alternate Picking", category: "Technique", duration: 15, thumbnail: "https://picsum.photos/seed/lesson6/400/225" },
];
