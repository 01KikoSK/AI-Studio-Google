
import React from 'react';

export const MuteIcon: React.FC = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 4L8 8H4v8h4l4 4V4zm-2 2.83L12 9.66v4.69l-2-2v-2.83z" fillOpacity="0.7"/>
    <path d="M12 4v16l4-4h4V8h-4l-4-4zM6 10v4h3.17L12 16.83V7.17L9.17 10H6z" fill="currentColor"/>
  </svg>
);
