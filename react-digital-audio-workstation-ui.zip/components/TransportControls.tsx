
import React from 'react';
import { PlayIcon } from './icons/PlayIcon';
import { StopIcon } from './icons/StopIcon';
import { RecordIcon } from './icons/RecordIcon';

interface TransportControlsProps {
  isPlaying: boolean;
  onPlayPause: () => void;
  onStop: () => void;
  playheadPosition: number;
  pixelsPerBeat: number;
}

export const TransportControls: React.FC<TransportControlsProps> = ({
  isPlaying,
  onPlayPause,
  onStop,
  playheadPosition,
  pixelsPerBeat,
}) => {

  const formatTime = () => {
    const currentBeat = playheadPosition / pixelsPerBeat;
    const measure = Math.floor(currentBeat / 4) + 1;
    const beat = Math.floor(currentBeat % 4) + 1;
    const tick = Math.floor((currentBeat * 100) % 100);
    return `${String(measure).padStart(3, '0')}:${String(beat).padStart(2, '0')}:${String(tick).padStart(2, '0')}`;
  };

  return (
    <footer className="bg-gray-800 p-3 border-t border-gray-700 flex items-center justify-center space-x-6 shadow-lg">
      <div className="text-2xl font-mono bg-gray-900 px-4 py-1 rounded-md text-blue-300 w-40 text-center">
        {formatTime()}
      </div>
      <button
        onClick={onStop}
        className="p-3 bg-gray-700 rounded-md hover:bg-gray-600 transition-colors"
        aria-label="Stop"
      >
        <StopIcon />
      </button>
      <button
        onClick={onPlayPause}
        className={`p-3 rounded-md transition-colors ${
          isPlaying ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-700 hover:bg-gray-600'
        }`}
        aria-label={isPlaying ? 'Pause' : 'Play'}
      >
        <PlayIcon isPlaying={isPlaying} />
      </button>
      <button
        className="p-3 bg-gray-700 rounded-md hover:bg-gray-600 transition-colors"
        aria-label="Record"
      >
        <RecordIcon />
      </button>
    </footer>
  );
};
