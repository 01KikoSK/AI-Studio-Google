
import React from 'react';

interface HeaderProps {
  projectName: string;
  setProjectName: (name: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ projectName, setProjectName }) => {
  return (
    <header className="bg-gray-800 p-3 border-b border-gray-700 flex items-center shadow-md">
      <div className="text-xl font-bold text-blue-400 mr-4">DAW UI</div>
      <input
        type="text"
        value={projectName}
        onChange={(e) => setProjectName(e.target.value)}
        className="bg-gray-700 text-white font-semibold rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
    </header>
  );
};
