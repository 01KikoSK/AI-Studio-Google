
import React, { useRef, useState, useCallback, MouseEvent } from 'react';
import type { Track, Clip } from '../types';
import { MuteIcon } from './icons/MuteIcon';
import { SoloIcon } from './icons/SoloIcon';

// Define helper component in the same file to avoid re-rendering issues
const TrackHeader: React.FC<{ track: Track; onUpdate: (id: string, updates: Partial<Track>) => void }> = ({ track, onUpdate }) => {
    return (
        <div className="h-28 flex flex-col justify-between p-2 border-b border-gray-700 bg-gray-800">
            <input 
                type="text" 
                value={track.name}
                onChange={(e) => onUpdate(track.id, { name: e.target.value })}
                className="bg-transparent font-bold text-sm w-full truncate focus:bg-gray-600 rounded px-1"
            />
            <div className="flex items-center space-x-2">
                <button
                    onClick={() => onUpdate(track.id, { isMuted: !track.isMuted })}
                    className={`p-1 rounded ${track.isMuted ? 'bg-red-500' : 'bg-gray-600 hover:bg-gray-500'}`}
                >
                    <MuteIcon />
                </button>
                <button
                    onClick={() => onUpdate(track.id, { isSoloed: !track.isSoloed })}
                    className={`p-1 rounded ${track.isSoloed ? 'bg-yellow-500' : 'bg-gray-600 hover:bg-gray-500'}`}
                >
                    <SoloIcon />
                </button>
                <div className={`w-2 h-2 rounded-full ${track.color}`}></div>
            </div>
            <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={track.volume}
                onChange={(e) => onUpdate(track.id, { volume: parseFloat(e.target.value) })}
                className="w-full h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
        </div>
    );
};

const TimelineClip: React.FC<{
    clip: Clip;
    trackColor: string;
    pixelsPerBeat: number;
    onUpdate: (id: string, updates: Partial<Clip>) => void;
    isMuted: boolean;
}> = ({ clip, trackColor, pixelsPerBeat, onUpdate, isMuted }) => {
    const [isDragging, setIsDragging] = useState(false);
    const [isResizing, setIsResizing] = useState(false);
    const dragOffsetRef = useRef(0);

    const handleDragStart = (e: MouseEvent<HTMLDivElement>) => {
        setIsDragging(true);
        dragOffsetRef.current = e.clientX - (clip.startBeat * pixelsPerBeat);
        e.stopPropagation();
    };

    const handleResizeStart = (e: MouseEvent<HTMLDivElement>) => {
        setIsResizing(true);
        dragOffsetRef.current = e.clientX - ((clip.startBeat + clip.durationBeats) * pixelsPerBeat);
        e.stopPropagation();
    };

    const handleMouseMove = useCallback((e: globalThis.MouseEvent) => {
        if (isDragging) {
            const newStartPixels = e.clientX - dragOffsetRef.current;
            const newStartBeat = Math.round(newStartPixels / pixelsPerBeat);
            onUpdate(clip.id, { startBeat: Math.max(0, newStartBeat) });
        }
        if (isResizing) {
            const newEndPixels = e.clientX - dragOffsetRef.current;
            const newDurationBeats = Math.round(newEndPixels / pixelsPerBeat) - clip.startBeat;
            onUpdate(clip.id, { durationBeats: Math.max(1, newDurationBeats) });
        }
    }, [isDragging, isResizing, pixelsPerBeat, onUpdate, clip.id, clip.startBeat]);

    const handleMouseUp = useCallback(() => {
        setIsDragging(false);
        setIsResizing(false);
    }, []);

    React.useEffect(() => {
        if (isDragging || isResizing) {
            window.addEventListener('mousemove', handleMouseMove);
            window.addEventListener('mouseup', handleMouseUp);
        }
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, isResizing, handleMouseMove, handleMouseUp]);

    const clipWidth = clip.durationBeats * pixelsPerBeat;
    const clipLeft = clip.startBeat * pixelsPerBeat;

    return (
        <div
            className={`absolute h-20 top-4 rounded-lg ${trackColor} p-2 text-white text-sm font-medium shadow-lg border-2 border-transparent hover:border-blue-400 cursor-grab ${isDragging ? 'cursor-grabbing shadow-xl z-10' : ''} ${isMuted ? 'opacity-50' : ''}`}
            style={{ left: `${clipLeft}px`, width: `${clipWidth}px` }}
            onMouseDown={handleDragStart}
        >
            {clip.name}
            <div 
                className="absolute right-0 top-0 w-2 h-full cursor-ew-resize"
                onMouseDown={handleResizeStart}
            />
        </div>
    );
};


interface TrackAreaProps {
  tracks: Track[];
  clips: Clip[];
  updateTrack: (id: string, updates: Partial<Track>) => void;
  addClip: (trackId: string, startBeat: number) => void;
  updateClip: (id:string, updates: Partial<Clip>) => void;
  playheadPosition: number;
  pixelsPerBeat: number;
  totalBeats: number;
}

export const TrackArea: React.FC<TrackAreaProps> = ({ tracks, clips, updateTrack, addClip, updateClip, playheadPosition, pixelsPerBeat, totalBeats }) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const trackHeadersRef = useRef<HTMLDivElement>(null);
  const timelineGridRef = useRef<HTMLDivElement>(null);

  const handleScroll = () => {
    if (scrollContainerRef.current && trackHeadersRef.current) {
      trackHeadersRef.current.scrollTop = scrollContainerRef.current.scrollTop;
    }
  };
  
  const isAnyTrackSoloed = tracks.some(t => t.isSoloed);

  const handleGridDoubleClick = (e: MouseEvent<HTMLDivElement>, trackId: string) => {
    if (timelineGridRef.current) {
        const rect = timelineGridRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left + timelineGridRef.current.scrollLeft;
        const beat = Math.floor(x / pixelsPerBeat);
        addClip(trackId, beat);
    }
  };

  const measureWidth = pixelsPerBeat * 4;
  const gridWidth = totalBeats * pixelsPerBeat;

  const renderGridLines = () => {
      let lines = [];
      for (let i = 0; i <= totalBeats; i++) {
          const isMeasureLine = i % 4 === 0;
          lines.push(
              <div 
                key={`line-${i}`}
                className={`absolute h-full ${isMeasureLine ? 'border-l border-gray-600' : 'border-l border-gray-700'}`}
                style={{ left: `${i * pixelsPerBeat}px` }}
              >
                {isMeasureLine && <span className="absolute -top-5 text-xs text-gray-500">{i/4 + 1}</span>}
              </div>
          )
      }
      return lines;
  }

  return (
    <div className="flex flex-grow overflow-hidden bg-gray-900">
      {/* Track Headers */}
      <div ref={trackHeadersRef} className="w-64 flex-shrink-0 overflow-hidden bg-gray-800 border-r border-gray-700">
        {tracks.map(track => (
          <TrackHeader key={track.id} track={track} onUpdate={updateTrack} />
        ))}
      </div>

      {/* Timeline */}
      <div ref={scrollContainerRef} onScroll={handleScroll} className="flex-grow overflow-auto">
        <div className="relative" style={{ height: `${tracks.length * 112}px` }}>
          {/* Timeline Grid */}
          <div ref={timelineGridRef} className="absolute top-0 left-0 w-full h-full">
            <div className="relative h-full" style={{ width: `${gridWidth}px`}}>
                <div 
                    className="absolute top-5 h-full w-full"
                    style={{ backgroundSize: `${measureWidth}px 100%`, backgroundImage: 'linear-gradient(to right, #4a5568 1px, transparent 1px)' }}
                ></div>
                {renderGridLines()}
            </div>
          </div>
          
          {/* Tracks and Clips */}
          <div className="relative">
            {tracks.map((track, index) => {
              const trackClips = clips.filter(c => c.trackId === track.id);
              const isMuted = track.isMuted || (isAnyTrackSoloed && !track.isSoloed);
              
              return (
                <div 
                    key={track.id} 
                    className="relative h-28 border-b border-gray-700"
                    onDoubleClick={(e) => handleGridDoubleClick(e, track.id)}
                >
                  <div className="relative h-full" style={{ width: `${gridWidth}px` }}>
                    {trackClips.map(clip => (
                      <TimelineClip 
                        key={clip.id} 
                        clip={clip} 
                        trackColor={track.color}
                        pixelsPerBeat={pixelsPerBeat}
                        onUpdate={updateClip}
                        isMuted={isMuted}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Playhead */}
          <div
            className="absolute top-0 w-0.5 h-full bg-yellow-300 z-20"
            style={{ left: `${playheadPosition}px` }}
          />
        </div>
      </div>
    </div>
  );
};
