
export interface Track {
  id: string;
  name: string;
  color: string;
  isMuted: boolean;
  isSoloed: boolean;
  volume: number; // 0 to 1
}

export interface Clip {
  id: string;
  trackId: string;
  startBeat: number;
  durationBeats: number;
  name: string;
}
