import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Header } from './components/Header';
import { TransportControls } from './components/TransportControls';
import { TrackArea } from './components/TrackArea';
import type { Track, Clip } from './types';
import { PlusIcon } from './components/icons/PlusIcon';

const initialTracks: Track[] = [
  { id: 'track-1', name: 'Acoustic Guitar', color: 'bg-blue-500', isMuted: false, isSoloed: false, volume: 0.8 },
  { id: 'track-2', name: 'Drums', color: 'bg-red-500', isMuted: false, isSoloed: false, volume: 1.0 },
  { id: 'track-3', name: 'Bass', color: 'bg-yellow-500', isMuted: true, isSoloed: false, volume: 0.9 },
];

const initialClips: Clip[] = [
  { id: 'clip-1', trackId: 'track-1', startBeat: 0, durationBeats: 8, name: 'Intro Melody' },
  { id: 'clip-2', trackId: 'track-2', startBeat: 0, durationBeats: 16, name: 'Basic Beat' },
  { id: 'clip-3', trackId: 'track-1', startBeat: 8, durationBeats: 8, name: 'Verse Melody' },
];

const App: React.FC = () => {
  const [projectName, setProjectName] = useState('My Awesome Song');
  const [tracks, setTracks] = useState<Track[]>(initialTracks);
  const [clips, setClips] = useState<Clip[]>(initialClips);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playheadPosition, setPlayheadPosition] = useState(0); // in pixels
  const [zoom, setZoom] = useState(40); // pixels per beat

  // Fix: Initialize useRef with null to avoid "Expected 1 arguments, but got 0" error and handle nullable type.
  const animationFrameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number | null>(null);

  const trackColors = ['bg-green-500', 'bg-purple-500', 'bg-pink-500', 'bg-indigo-500', 'bg-teal-500'];

  const addTrack = () => {
    const newTrackId = `track-${Date.now()}`;
    const newTrack: Track = {
      id: newTrackId,
      name: `Track ${tracks.length + 1}`,
      color: trackColors[tracks.length % trackColors.length],
      isMuted: false,
      isSoloed: false,
      volume: 0.8,
    };
    setTracks(prev => [...prev, newTrack]);
  };

  const updateTrack = (trackId: string, updates: Partial<Track>) => {
    setTracks(prev => prev.map(t => t.id === trackId ? { ...t, ...updates } : t));
  };

  const addClip = (trackId: string, startBeat: number) => {
    const newClip: Clip = {
      id: `clip-${Date.now()}`,
      trackId,
      startBeat,
      durationBeats: 4,
      name: 'New Clip'
    };
    setClips(prev => [...prev, newClip]);
  };
  
  const updateClip = (clipId: string, updates: Partial<Clip>) => {
    setClips(prev => prev.map(c => c.id === clipId ? { ...c, ...updates } : c));
  };

  const animate = useCallback((time: number) => {
    // Fix: Check for null to align with the updated ref type.
    if (lastTimeRef.current === null) {
      lastTimeRef.current = time;
    }
    const deltaTime = time - lastTimeRef.current;
    lastTimeRef.current = time;

    setPlayheadPosition(prev => {
        // Speed: 1 zoom unit (1 beat) per second -> zoom pixels / 1000 ms
        const newPos = prev + (zoom / 1000) * deltaTime;
        // Simple loop for now
        if (newPos > zoom * 64) return 0;
        return newPos;
    });

    animationFrameRef.current = requestAnimationFrame(animate);
  }, [zoom]);

  useEffect(() => {
    if (isPlaying) {
      lastTimeRef.current = performance.now();
      animationFrameRef.current = requestAnimationFrame(animate);
    } else {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, animate]);

  const handleStop = () => {
      setIsPlaying(false);
      setPlayheadPosition(0);
  }
  
  return (
    <div className="flex flex-col h-screen bg-gray-900 text-white font-sans overflow-hidden">
      <Header projectName={projectName} setProjectName={setProjectName} />
      <div className="flex-grow flex overflow-hidden">
        <div className="w-64 bg-gray-800 p-2 flex flex-col border-r border-gray-700">
          <button
            onClick={addTrack}
            className="flex items-center justify-center gap-2 w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors duration-200 mb-4"
          >
            <PlusIcon />
            Add Track
          </button>
           <div className="flex items-center space-x-2 text-sm">
              <label htmlFor="zoom-slider">Zoom</label>
              <input
                id="zoom-slider"
                type="range"
                min="10"
                max="100"
                value={zoom}
                onChange={(e) => setZoom(Number(e.target.value))}
                className="w-full"
              />
          </div>
        </div>
        <main className="flex-grow flex flex-col">
          <TrackArea
            tracks={tracks}
            clips={clips}
            updateTrack={updateTrack}
            addClip={addClip}
            updateClip={updateClip}
            playheadPosition={playheadPosition}
            pixelsPerBeat={zoom}
            totalBeats={64}
          />
        </main>
      </div>
      <TransportControls
        isPlaying={isPlaying}
        onPlayPause={() => setIsPlaying(p => !p)}
        onStop={handleStop}
        playheadPosition={playheadPosition}
        pixelsPerBeat={zoom}
      />
    </div>
  );
};

export default App;
