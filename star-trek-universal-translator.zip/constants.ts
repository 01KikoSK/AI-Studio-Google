
import type { Language } from './types';

export const SUPPORTED_LANGUAGES: Language[] = [
  { code: 'es', name: 'Spanish' },
  { code: 'de', name: 'German' },
  { code: 'fr', name: 'French' },
  { code: 'it', name: 'Italian' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ko', name: 'Korean' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ru', name: 'Russian' },
  { code: 'zh', name: 'Mandarin Chinese' },
  { code: 'tlh', name: 'Klingon' }, // For thematic fun!
];
