
export interface Language {
  code: string;
  name: string;
}

export interface ConversationEntry {
  speaker: 'user' | 'translator';
  text: string;
  timestamp: number;
}

export type TranslatorStatus = 'OFF' | 'INITIALIZING' | 'LISTENING' | 'PROCESSING' | 'ERROR';
