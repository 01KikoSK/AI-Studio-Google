
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import DisplayScreen from './components/DisplayScreen';
import ControlPanel from './components/ControlPanel';
import { useUniversalTranslator } from './hooks/useUniversalTranslator';
import { SUPPORTED_LANGUAGES } from './constants';
import type { Language } from './types';

const App: React.FC = () => {
  const [targetLanguage, setTargetLanguage] = useState<Language>(SUPPORTED_LANGUAGES[2]); // Default to French
  const {
    status,
    conversation,
    error,
    startSession,
    stopSession,
  } = useUniversalTranslator();

  const isTranslatorActive = status !== 'OFF' && status !== 'ERROR';

  const handleToggleTranslator = useCallback(() => {
    if (isTranslatorActive) {
      stopSession();
    } else {
      startSession(targetLanguage.name);
    }
  }, [isTranslatorActive, stopSession, startSession, targetLanguage.name]);

  const handleLanguageChange = useCallback((langCode: string) => {
    const newLang = SUPPORTED_LANGUAGES.find(l => l.code === langCode);
    if (newLang) {
      setTargetLanguage(newLang);
    }
  }, []);


  return (
    <div className="min-h-screen bg-slate-900 text-cyan-200 flex flex-col items-center justify-center p-4 font-mono">
      <div className="w-full max-w-2xl h-[90vh] max-h-[800px] bg-black border-2 border-cyan-400/50 rounded-tl-3xl rounded-br-3xl shadow-2xl shadow-cyan-500/20 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-grow flex flex-col p-4 md:p-6 space-y-4 overflow-hidden">
            <DisplayScreen conversation={conversation} />
            {error && <div className="text-center text-red-500 bg-red-900/50 p-2 rounded-md">ERROR: {error}</div>}
            <ControlPanel
                status={status}
                isTranslatorActive={isTranslatorActive}
                selectedLanguage={targetLanguage}
                onLanguageChange={handleLanguageChange}
                onToggleTranslator={handleToggleTranslator}
                languages={SUPPORTED_LANGUAGES}
            />
        </main>
      </div>
       <footer className="text-center text-xs text-slate-500 pt-4">
        STARFLEET UNIVERSAL TRANSLATOR // MODEL: GEMINI 2.5 FLASH // FOR AUTHORIZED PERSONNEL ONLY
      </footer>
    </div>
  );
};

export default App;
