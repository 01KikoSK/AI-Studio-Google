
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="flex-shrink-0 bg-slate-800 p-4 flex items-center justify-between border-b-2 border-cyan-400/50">
      <div className="flex items-center space-x-4">
        <div className="w-12 h-12 bg-cyan-400 rounded-full flex items-center justify-center text-slate-900 font-bold text-lg">
          U.T.
        </div>
        <div>
          <h1 className="text-xl font-bold text-orange-400 tracking-widest">UNIVERSAL TRANSLATOR</h1>
          <p className="text-xs text-cyan-300">STARFLEET COMMAND // LIVE AUDIO FEED</p>
        </div>
      </div>
       <div className="w-4 h-8 bg-orange-400 rounded-br-full rounded-tr-full" />
    </header>
  );
};

export default Header;
