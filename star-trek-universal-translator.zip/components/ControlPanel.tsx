
import React from 'react';
import type { Language, TranslatorStatus } from '../types';
import { PowerIcon, GlobeIcon, SignalIcon } from './Icons';

interface ControlPanelProps {
  status: TranslatorStatus;
  isTranslatorActive: boolean;
  selectedLanguage: Language;
  onLanguageChange: (langCode: string) => void;
  onToggleTranslator: () => void;
  languages: Language[];
}

const StatusIndicator: React.FC<{ status: TranslatorStatus }> = ({ status }) => {
    let text = "SYSTEM OFFLINE";
    let color = "bg-slate-500";
    let pulse = false;

    switch(status) {
        case 'INITIALIZING':
            text = "INITIALIZING...";
            color = "bg-yellow-500";
            pulse = true;
            break;
        case 'LISTENING':
            text = "LISTENING...";
            color = "bg-green-500";
            pulse = true;
            break;
        case 'PROCESSING':
            text = "TRANSLATING...";
            color = "bg-cyan-500";
            pulse = true;
            break;
        case 'ERROR':
            text = "SYSTEM ERROR";
            color = "bg-red-500";
            break;
        case 'OFF':
        default:
            text = "AWAITING ACTIVATION";
            color = "bg-slate-600";
            break;
    }

    return (
        <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${color} ${pulse ? 'animate-pulse' : ''}`}></div>
            <span className="text-sm font-bold tracking-wider">{text}</span>
        </div>
    );
};

const ControlPanel: React.FC<ControlPanelProps> = ({
  status,
  isTranslatorActive,
  selectedLanguage,
  onLanguageChange,
  onToggleTranslator,
  languages,
}) => {
  return (
    <div className="flex-shrink-0 bg-slate-800 p-4 border-t-2 border-cyan-400/50 rounded-bl-3xl rounded-tr-3xl">
      <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
        <div className="flex items-center space-x-4">
          <button
            onClick={onToggleTranslator}
            disabled={status === 'INITIALIZING'}
            className={`w-20 h-20 rounded-full flex flex-col items-center justify-center transition-all duration-300 text-white font-bold
              ${isTranslatorActive ? 'bg-red-600 hover:bg-red-700 shadow-lg shadow-red-500/50' : 'bg-green-600 hover:bg-green-700 shadow-lg shadow-green-500/50'}
              ${status === 'INITIALIZING' ? 'opacity-50 cursor-not-allowed' : ''}
            `}
          >
            <PowerIcon className="w-8 h-8 mb-1" />
            <span className="text-xs">{isTranslatorActive ? 'DEACTIVATE' : 'ACTIVATE'}</span>
          </button>
          <div className="flex flex-col justify-center">
            <StatusIndicator status={status} />
            <div className="flex items-center space-x-2 mt-2 text-cyan-300">
                <SignalIcon className="w-4 h-4" />
                <span className="text-sm">Live Audio Channel Open</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <GlobeIcon className="w-6 h-6 text-orange-400" />
          <select
            value={selectedLanguage.code}
            onChange={(e) => onLanguageChange(e.target.value)}
            disabled={isTranslatorActive}
            className="bg-slate-900 border border-cyan-400/50 rounded-md px-3 py-2 text-orange-300 focus:ring-2 focus:ring-orange-500 focus:outline-none disabled:opacity-50"
          >
            {languages.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.name}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};

export default ControlPanel;
