
import React, { useRef, useEffect } from 'react';
import type { ConversationEntry } from '../types';

interface DisplayScreenProps {
  conversation: ConversationEntry[];
}

const DisplayScreen: React.FC<DisplayScreenProps> = ({ conversation }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversation]);

  return (
    <div ref={scrollRef} className="flex-grow bg-slate-900/50 border border-cyan-400/30 rounded-lg p-4 overflow-y-auto space-y-4">
      {conversation.length === 0 && (
          <div className="h-full flex items-center justify-center text-slate-500">
            <p>// STANDING BY FOR AUDIO INPUT //</p>
          </div>
      )}
      {conversation.map((entry) => (
        <div key={entry.timestamp} className={`flex flex-col ${entry.speaker === 'user' ? 'items-start' : 'items-end'}`}>
          <div className={`max-w-[80%] p-3 rounded-lg ${
              entry.speaker === 'user'
                ? 'bg-cyan-900/50 text-cyan-200 rounded-bl-none'
                : 'bg-orange-900/70 text-orange-200 rounded-br-none'
            }`}>
             <p className="text-xs font-bold mb-1 opacity-70">
                {entry.speaker === 'user' ? 'USER INPUT' : 'TRANSLATED OUTPUT'}
             </p>
            <p>{entry.text}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default DisplayScreen;
