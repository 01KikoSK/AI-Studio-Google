
import React from 'react';

export const PowerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M5.636 5.636a9 9 0 1 0 12.728 0M12 3v9" />
  </svg>
);

export const GlobeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 0 0 8.491-6.491m-1.428-.857A10.5 10.5 0 0 1 12 21m-8.491-6.491A9.004 9.004 0 0 0 12 21m0-18a9.004 9.004 0 0 0-8.491 6.491m1.428.857A10.5 10.5 0 0 1 12 3m0 18A9 9 0 0 0 3.509 6.491m1.428.857a10.5 10.5 0 0 1 14.127 0M12 3c-1.84 0-3.6.4-5.166 1.125m10.332 0A10.5 10.5 0 0 1 12 3m-7.08 8.085A10.5 10.5 0 0 1 12 3m.915 18A10.5 10.5 0 0 1 12 21" />
  </svg>
);

export const SignalIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 0 1 7.424 0M5.136 11.886a9 9 0 0 1 13.728 0M2 8.734a12.75 12.75 0 0 1 20 0" />
  </svg>
);
