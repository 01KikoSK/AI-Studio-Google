
import { OwlSpecies } from './types';

export const OWL_SPECIES_LIST: OwlSpecies[] = [
    OwlSpecies.SNOWY_OWL,
    OwlSpecies.BARN_OWL,
    OwlSpecies.GREAT_HORNED_OWL,
    OwlSpecies.EURASIAN_EAGLE_OWL,
    OwlSpecies.BURROWING_OWL,
    OwlSpecies.SPECTACLED_OWL,
];
