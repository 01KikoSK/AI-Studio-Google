
import { GoogleGenAI, Type } from '@google/genai';
import { OwlSpecies, OwlData } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const fetchOwlFacts = async (species: OwlSpecies): Promise<OwlData> => {
  // Step 1: Get facts and an image prompt from Gemini Flash
  const textModel = 'gemini-2.5-flash';
  const textPrompt = `
    Provide 5 interesting, little-known facts about the ${species}.
    Also, provide a simple, descriptive prompt that I can use with an image generation model to create a realistic, high-quality, photorealistic image of this owl in its natural habitat at night.
    Return the response as a JSON object with two keys: "facts" (an array of strings) and "imagePrompt" (a string).
  `;
  
  const factSchema = {
    type: Type.OBJECT,
    properties: {
      facts: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
        description: 'An array of interesting facts about the owl.',
      },
      imagePrompt: {
        type: Type.STRING,
        description: 'A prompt for an image generation model.',
      },
    },
    required: ['facts', 'imagePrompt'],
  };

  const textResponse = await ai.models.generateContent({
    model: textModel,
    contents: textPrompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: factSchema,
    },
  });

  const textResult = JSON.parse(textResponse.text);
  const { facts, imagePrompt } = textResult;
  
  if (!facts || !imagePrompt || facts.length === 0) {
      throw new Error("Failed to get valid facts and image prompt from the model.");
  }


  // Step 2: Generate an image using the obtained prompt with Imagen
  const imageModel = 'imagen-4.0-generate-001';
  
  const imageResponse = await ai.models.generateImages({
    model: imageModel,
    prompt: imagePrompt,
    config: {
      numberOfImages: 1,
      outputMimeType: 'image/jpeg',
      aspectRatio: '1:1',
    },
  });

  if (!imageResponse.generatedImages || imageResponse.generatedImages.length === 0) {
    throw new Error('Image generation failed.');
  }

  const base64ImageBytes: string = imageResponse.generatedImages[0].image.imageBytes;
  const imageUrl = `data:image/jpeg;base64,${base64ImageBytes}`;

  return {
    facts,
    imageUrl,
  };
};
