
import React, { useState, useCallback } from 'react';
import { OwlSpecies, OwlData } from './types';
import { fetchOwlFacts } from './services/geminiService';
import Header from './components/Header';
import OwlSelector from './components/OwlSelector';
import FactCard from './components/FactCard';
import Spinner from './components/Spinner';
import ErrorMessage from './components/ErrorMessage';

const App: React.FC = () => {
  const [selectedOwl, setSelectedOwl] = useState<OwlSpecies | ''>('');
  const [owlData, setOwlData] = useState<OwlData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFetchFacts = useCallback(async () => {
    if (!selectedOwl) {
      setError('Please select an owl species first.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setOwlData(null);

    try {
      const data = await fetchOwlFacts(selectedOwl);
      setOwlData(data);
    } catch (e) {
      console.error(e);
      setError('Failed to fetch facts. Please check your API key and try again.');
    } finally {
      setIsLoading(false);
    }
  }, [selectedOwl]);

  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-4xl mx-auto">
        <Header />
        <main className="mt-8">
          <p className="text-center text-lg text-slate-300 mb-6">
            Select an owl species to uncover fascinating facts and generate a unique image.
          </p>
          <OwlSelector
            selectedOwl={selectedOwl}
            onOwlChange={setSelectedOwl}
            onFetchFacts={handleFetchFacts}
            isLoading={isLoading}
          />
          <div className="mt-12">
            {isLoading && <Spinner />}
            {error && <ErrorMessage message={error} />}
            {owlData && !isLoading && <FactCard data={owlData} species={selectedOwl || ''} />}
          </div>
        </main>
         <footer className="text-center text-slate-500 mt-12 text-sm">
            <p>Powered by Google Gemini. Images are AI-generated.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
