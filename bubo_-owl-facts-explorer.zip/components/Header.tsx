
import React from 'react';

const OwlIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 24 24" 
        fill="currentColor" 
        className={className}
    >
        <path d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2zm0 2c-1.48 0-2.833.407-4 1.103V12a4 4 0 118 0V5.103A7.95 7.95 0 0012 4zm-5.938 1.503A8.002 8.002 0 0112 4.001a8.002 8.002 0 015.938 1.502C18.438 6.416 19 7.648 19 9c0 1.954-.925 3.65-2.33 4.717A5.98 5.98 0 0012 18a5.98 5.98 0 00-4.67-4.283C5.925 12.65 5 10.954 5 9c0-1.352.562-2.584 1.062-3.497zM12 13a1 1 0 100 2 1 1 0 000-2z" />
        <circle cx="9" cy="9" r="1.5" />
        <circle cx="15" cy="9" r="1.5" />
    </svg>
);


const Header: React.FC = () => {
  return (
    <header className="text-center">
        <div className="flex justify-center items-center gap-4">
            <OwlIcon className="w-12 h-12 text-teal-400"/>
            <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-300 to-sky-400">
                Bubo
            </h1>
        </div>
        <h2 className="mt-2 text-xl text-slate-400">Owl Facts Explorer</h2>
    </header>
  );
};

export default Header;
