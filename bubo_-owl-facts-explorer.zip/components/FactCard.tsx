
import React from 'react';
import { OwlData } from '../types';

interface FactCardProps {
  data: OwlData;
  species: string;
}

const FactCard: React.FC<FactCardProps> = ({ data, species }) => {
  return (
    <div className="bg-slate-800/70 border border-slate-700 rounded-xl shadow-2xl overflow-hidden animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
        <div className="p-6 md:p-8">
            <h3 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-300 to-sky-400 mb-6">Facts about the {species}</h3>
            <ul className="space-y-4">
            {data.facts.map((fact, index) => (
                <li key={index} className="flex items-start">
                    <svg className="w-6 h-6 text-teal-400 mr-3 flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <span className="text-slate-300 text-lg">{fact}</span>
                </li>
            ))}
            </ul>
        </div>
        <div className="relative w-full h-80 md:h-full min-h-[300px]">
            <img 
                src={data.imageUrl} 
                alt={`AI-generated image of a ${species}`}
                className="w-full h-full object-cover"
            />
             <div className="absolute inset-0 bg-gradient-to-t from-slate-800/50 via-transparent to-transparent md:bg-gradient-to-l md:from-slate-800/50 md:via-transparent md:to-transparent"></div>
        </div>
      </div>
       <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.7s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default FactCard;
