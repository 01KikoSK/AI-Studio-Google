
export enum OwlSpecies {
    SNOWY_OWL = 'Snowy Owl',
    BARN_OWL = 'Barn Owl',
    GREAT_HORNED_OWL = 'Great Horned Owl',
    EURASIAN_EAGLE_OWL = 'Eurasian Eagle-Owl',
    BURROWING_OWL = 'Burrowing Owl',
    SPECTACLED_OWL = 'Spectacled Owl',
}

export interface OwlData {
    facts: string[];
    imageUrl: string;
}
