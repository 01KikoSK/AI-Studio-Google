
export enum PrimitiveType {
  Cube = 'Cube',
  Sphere = 'Sphere',
  Cylinder = 'Cylinder',
  Cone = 'Cone',
  Torus = 'Torus',
  Plane = 'Plane',
}

export type MaterialType = 'standard' | 'physical' | 'toon' | 'basic';

export interface MaterialProperties {
  color: string;
  type: MaterialType;
  wireframe: boolean;
}

export type Vector3 = [number, number, number];

export interface Transform {
  position: Vector3;
  rotation: Vector3;
  scale: Vector3;
}

export interface SceneObject {
  id: string;
  name: string;
  type: PrimitiveType;
  transform: Transform;
  material: MaterialProperties;
}

export interface Scene {
  objects: SceneObject[];
}
