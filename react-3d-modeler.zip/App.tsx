
import React, { useState, useCallback, useRef } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import PropertiesPanel from './components/PropertiesPanel';
import CanvasView from './components/CanvasView';
import Toolbar from './components/Toolbar';
import { SceneObject, PrimitiveType, Transform } from './types';

const App: React.FC = () => {
  const [objects, setObjects] = useState<SceneObject[]>([]);
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>(null);
  const [transformMode, setTransformMode] = useState<'translate' | 'rotate' | 'scale'>('translate');
  const importFileRef = useRef<HTMLInputElement>(null);

  const addObject = useCallback((type: PrimitiveType) => {
    const newObject: SceneObject = {
      id: crypto.randomUUID(),
      name: `${type} ${objects.filter(o => o.type === type).length + 1}`,
      type,
      transform: {
        position: [0, 1, 0],
        rotation: [0, 0, 0],
        scale: [1, 1, 1],
      },
      material: {
        color: `#${Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0')}`,
        type: 'standard',
        wireframe: false,
      },
    };
    if (type === PrimitiveType.Plane) {
        newObject.transform.position = [0, 0, 0];
    }
    setObjects((prev) => [...prev, newObject]);
    setSelectedObjectId(newObject.id);
  }, [objects]);

  const updateObject = useCallback((id: string, newProps: Partial<SceneObject>) => {
    setObjects((prev) =>
      prev.map((obj) => (obj.id === id ? { ...obj, ...newProps } : obj))
    );
  }, []);
  
  const updateObjectTransform = useCallback((id: string, newTransform: Transform) => {
    setObjects((prev) =>
      prev.map((obj) => (obj.id === id ? { ...obj, transform: newTransform } : obj))
    );
  }, []);

  const deleteObject = useCallback((id: string) => {
    setObjects(prev => prev.filter(obj => obj.id !== id));
    if (selectedObjectId === id) {
        setSelectedObjectId(null);
    }
  }, [selectedObjectId]);

  const handleExport = () => {
    const sceneData = JSON.stringify({ objects }, null, 2);
    const blob = new Blob([sceneData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'scene.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportClick = () => {
    importFileRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const result = e.target?.result;
          if (typeof result === 'string') {
            const scene = JSON.parse(result);
            if (scene.objects && Array.isArray(scene.objects)) {
              setObjects(scene.objects);
              setSelectedObjectId(null);
            } else {
              alert('Invalid scene file format.');
            }
          }
        } catch (error) {
          alert('Error parsing scene file.');
          console.error(error);
        }
      };
      reader.readAsText(file);
    }
    // Reset file input
    if (importFileRef.current) {
        importFileRef.current.value = '';
    }
  };


  const selectedObject = objects.find((obj) => obj.id === selectedObjectId) || null;

  return (
    <div className="h-screen w-screen flex flex-col antialiased">
      <Header />
      <div className="flex flex-grow h-0 relative">
        <Sidebar
          objects={objects}
          selectedObjectId={selectedObjectId}
          onAddObject={addObject}
          onSelectObject={setSelectedObjectId}
        />
        <main className="flex-grow flex flex-col relative">
            <Toolbar 
                transformMode={transformMode}
                setTransformMode={setTransformMode}
                onImport={handleImportClick}
                onExport={handleExport}
            />
            <CanvasView
                objects={objects}
                selectedObjectId={selectedObjectId}
                transformMode={transformMode}
                setSelectedObjectId={setSelectedObjectId}
                onUpdateObjectTransform={updateObjectTransform}
            />
        </main>
        <PropertiesPanel
          selectedObject={selectedObject}
          onUpdateObject={updateObject}
          onDeleteObject={deleteObject}
        />
        <input
            type="file"
            ref={importFileRef}
            onChange={handleFileChange}
            accept=".json"
            className="hidden"
        />
      </div>
    </div>
  );
};

export default App;
