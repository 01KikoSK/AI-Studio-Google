
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-gray-950 text-white h-12 flex-shrink-0 flex items-center px-4 border-b border-gray-800">
      <div className="flex items-center space-x-2">
        <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-sky-500 to-blue-600"></div>
        <h1 className="text-lg font-bold text-gray-100">React 3D Modeler</h1>
      </div>
    </header>
  );
};

export default Header;
