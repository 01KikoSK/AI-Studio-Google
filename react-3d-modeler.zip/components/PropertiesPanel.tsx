
import React from 'react';
import { SceneObject, Transform, MaterialProperties, Vector3, MaterialType } from '../types';
import { TrashIcon } from './icons';

interface PropertiesPanelProps {
  selectedObject: SceneObject | null;
  onUpdateObject: (id: string, newProps: Partial<SceneObject>) => void;
  onDeleteObject: (id: string) => void;
}

const Vector3Input: React.FC<{
  label: string;
  value: Vector3;
  onChange: (newValue: Vector3) => void;
  step?: number;
}> = ({ label, value, onChange, step = 0.1 }) => {
  const handleChange = (index: number, val: string) => {
    const num = parseFloat(val);
    if (!isNaN(num)) {
      const newValue = [...value] as Vector3;
      newValue[index] = num;
      onChange(newValue);
    }
  };

  return (
    <div>
      <label className="text-xs font-semibold text-gray-400">{label}</label>
      <div className="flex space-x-2 mt-1">
        {['X', 'Y', 'Z'].map((axis, i) => (
          <div key={axis} className="relative flex-1">
            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-xs text-gray-500">{axis}</span>
            <input
              type="number"
              step={step}
              value={value[i]}
              onChange={(e) => handleChange(i, e.target.value)}
              className="w-full bg-gray-700 text-white pl-6 pr-2 py-1 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
        ))}
      </div>
    </div>
  );
};

const PropertiesPanel: React.FC<PropertiesPanelProps> = ({ selectedObject, onUpdateObject, onDeleteObject }) => {
  if (!selectedObject) {
    return (
      <aside className="w-72 bg-gray-900 text-white flex-shrink-0 border-l border-gray-800 p-4">
        <div className="flex items-center justify-center h-full">
          <p className="text-gray-500">No object selected</p>
        </div>
      </aside>
    );
  }

  const handleTransformChange = (newTransform: Partial<Transform>) => {
    onUpdateObject(selectedObject.id, {
      transform: { ...selectedObject.transform, ...newTransform },
    });
  };
  
  const handleMaterialChange = (newMaterial: Partial<MaterialProperties>) => {
    onUpdateObject(selectedObject.id, {
      material: { ...selectedObject.material, ...newMaterial },
    });
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateObject(selectedObject.id, { name: e.target.value });
  }

  return (
    <aside className="w-72 bg-gray-900 text-white flex-shrink-0 border-l border-gray-800 p-4 overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
            <input 
                value={selectedObject.name}
                onChange={handleNameChange}
                className="text-lg font-bold bg-transparent focus:bg-gray-800 w-full p-1 -m-1 rounded-md focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
            <button 
                onClick={() => onDeleteObject(selectedObject.id)} 
                className="p-2 text-gray-400 hover:text-red-500 hover:bg-gray-800 rounded-md transition"
                title="Delete Object"
            >
                <TrashIcon className="w-5 h-5"/>
            </button>
        </div>
        
        <div className="space-y-4">
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider border-b border-gray-800 pb-2">Transform</h3>
            <Vector3Input
                label="Position"
                value={selectedObject.transform.position}
                onChange={(position) => handleTransformChange({ position })}
            />
            <Vector3Input
                label="Rotation"
                value={selectedObject.transform.rotation}
                onChange={(rotation) => handleTransformChange({ rotation })}
            />
            <Vector3Input
                label="Scale"
                value={selectedObject.transform.scale}
                onChange={(scale) => handleTransformChange({ scale })}
            />

            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider border-b border-gray-800 pb-2 pt-4">Material</h3>
            <div>
                <label className="text-xs font-semibold text-gray-400">Color</label>
                <div className="flex items-center space-x-2 mt-1">
                    <input
                        type="color"
                        value={selectedObject.material.color}
                        onChange={(e) => handleMaterialChange({ color: e.target.value })}
                        className="w-8 h-8 p-0 border-none rounded-md bg-gray-700 cursor-pointer"
                    />
                    <input
                        type="text"
                        value={selectedObject.material.color}
                        onChange={(e) => handleMaterialChange({ color: e.target.value })}
                        className="w-full bg-gray-700 text-white px-2 py-1 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                    />
                </div>
            </div>
            
             <div>
                <label htmlFor="material-type" className="text-xs font-semibold text-gray-400">Type</label>
                <select 
                    id="material-type"
                    value={selectedObject.material.type}
                    onChange={(e) => handleMaterialChange({ type: e.target.value as MaterialType })}
                    className="w-full bg-gray-700 text-white px-2 py-1 mt-1 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                    <option value="standard">Standard</option>
                    <option value="physical">Physical</option>
                    <option value="toon">Toon</option>
                    <option value="basic">Basic</option>
                </select>
            </div>
            
            <div className="flex items-center justify-between pt-2">
                <label htmlFor="wireframe" className="text-xs font-semibold text-gray-400">Wireframe</label>
                <input
                    id="wireframe"
                    type="checkbox"
                    checked={selectedObject.material.wireframe}
                    onChange={(e) => handleMaterialChange({ wireframe: e.target.checked })}
                    className="w-4 h-4 rounded bg-gray-700 text-sky-600 focus:ring-sky-500 border-gray-600"
                />
            </div>
        </div>
    </aside>
  );
};

export default PropertiesPanel;
