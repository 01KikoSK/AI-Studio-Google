
import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, TransformControls, useCursor } from '@react-three/drei';
import * as THREE from 'three';
import { SceneObject, PrimitiveType, Transform } from '../types';

type TransformMode = 'translate' | 'rotate' | 'scale';

const Geometry: React.FC<{ type: PrimitiveType }> = ({ type }) => {
  switch (type) {
    case PrimitiveType.Cube:
      return <boxGeometry />;
    case PrimitiveType.Sphere:
      return <sphereGeometry args={[1, 32, 32]} />;
    case PrimitiveType.Cylinder:
      return <cylinderGeometry args={[1, 1, 2, 32]} />;
    case PrimitiveType.Cone:
      return <coneGeometry args={[1, 2, 32]} />;
    case PrimitiveType.Torus:
      return <torusGeometry args={[1, 0.4, 16, 100]} />;
    case PrimitiveType.Plane:
        return <planeGeometry args={[10, 10]}/>;
    default:
      return <boxGeometry />;
  }
};

const Material: React.FC<{
    color: string;
    type: string;
    wireframe: boolean;
}> = ({ color, type, wireframe }) => {
  const materialProps = { color, wireframe };
  switch (type) {
    case 'physical':
      return <meshPhysicalMaterial {...materialProps} />;
    case 'toon':
      return <meshToonMaterial {...materialProps} />;
    case 'basic':
        return <meshBasicMaterial {...materialProps} />;
    case 'standard':
    default:
      return <meshStandardMaterial {...materialProps} />;
  }
};


const ObjectMesh: React.FC<{
  object: SceneObject;
  isSelected: boolean;
  onSelect: (id: string | null) => void;
}> = ({ object, isSelected, onSelect }) => {
  const [hovered, setHovered] = React.useState(false);
  useCursor(hovered);

  return (
    <mesh
      position={object.transform.position}
      rotation={new THREE.Euler(...object.transform.rotation)}
      scale={object.transform.scale}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(object.id);
      }}
      onPointerOver={(e) => { e.stopPropagation(); setHovered(true); }}
      onPointerOut={() => setHovered(false)}
    >
      <Geometry type={object.type} />
      <Material {...object.material} />
    </mesh>
  );
};


interface CanvasViewProps {
  objects: SceneObject[];
  selectedObjectId: string | null;
  transformMode: TransformMode;
  setSelectedObjectId: (id: string | null) => void;
  onUpdateObjectTransform: (id: string, newTransform: Transform) => void;
}

const CanvasView: React.FC<CanvasViewProps> = ({
  objects,
  selectedObjectId,
  transformMode,
  setSelectedObjectId,
  onUpdateObjectTransform,
}) => {
  const selectedObject = objects.find((obj) => obj.id === selectedObjectId);

  const controlsRef = React.useRef<any>(null);

  React.useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (controlsRef.current) {
        switch (event.key) {
          case 'w':
          case 'W':
            controlsRef.current.mode = 'translate';
            break;
          case 'e':
          case 'E':
            controlsRef.current.mode = 'rotate';
            break;
          case 'r':
          case 'R':
            controlsRef.current.mode = 'scale';
            break;
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="flex-grow bg-gray-800 relative" onClick={() => setSelectedObjectId(null)}>
      <Canvas camera={{ position: [5, 5, 5], fov: 35 }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[10, 10, 5]} intensity={1.5} />
          <hemisphereLight groundColor="black" intensity={0.5}/>
          
          <gridHelper args={[100, 100, '#444', '#888']} />

          {objects.map((obj) => (
            <ObjectMesh
              key={obj.id}
              object={obj}
              isSelected={obj.id === selectedObjectId}
              onSelect={setSelectedObjectId}
            />
          ))}

          {selectedObject && controlsRef.current && (
            <TransformControls
              ref={controlsRef}
              object={controlsRef.current.object}
              mode={transformMode}
              onObjectChange={(e) => {
                if (e?.target.object) {
                  const { position, rotation, scale } = e.target.object;
                  onUpdateObjectTransform(selectedObject.id, {
                    position: [position.x, position.y, position.z],
                    rotation: [rotation.x, rotation.y, rotation.z],
                    scale: [scale.x, scale.y, scale.z],
                  });
                }
              }}
            />
          )}

          <OrbitControls makeDefault />
        </Suspense>
      </Canvas>
    </div>
  );
};

export default CanvasView;
