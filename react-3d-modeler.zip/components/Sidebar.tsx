
import React from 'react';
import { PrimitiveType, SceneObject } from '../types';
import { CubeIcon, SphereIcon, CylinderIcon, ConeIcon, TorusIcon, PlaneIcon } from './icons';

interface SidebarProps {
  objects: SceneObject[];
  selectedObjectId: string | null;
  onAddObject: (type: PrimitiveType) => void;
  onSelectObject: (id: string | null) => void;
}

const PrimitiveButton: React.FC<{ type: PrimitiveType; onClick: () => void }> = ({ type, onClick }) => {
  const icons: { [key in PrimitiveType]: React.ReactNode } = {
    [PrimitiveType.Cube]: <CubeIcon className="w-8 h-8" />,
    [PrimitiveType.Sphere]: <SphereIcon className="w-8 h-8" />,
    [PrimitiveType.Cylinder]: <CylinderIcon className="w-8 h-8" />,
    [PrimitiveType.Cone]: <ConeIcon className="w-8 h-8" />,
    [PrimitiveType.Torus]: <TorusIcon className="w-8 h-8" />,
    [PrimitiveType.Plane]: <PlaneIcon className="w-8 h-8" />,
  };

  return (
    <button
      onClick={onClick}
      title={`Add ${type}`}
      className="flex flex-col items-center justify-center p-2 rounded-lg bg-gray-700 text-gray-300 hover:bg-gray-600 hover:text-white transition-all duration-150"
    >
      {icons[type]}
      <span className="text-xs mt-1">{type}</span>
    </button>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ objects, selectedObjectId, onAddObject, onSelectObject }) => {
  return (
    <aside className="w-64 bg-gray-900 text-white flex-shrink-0 flex flex-col border-r border-gray-800">
      <div className="p-4 border-b border-gray-800">
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Add Object</h2>
        <div className="grid grid-cols-3 gap-2 mt-4">
          {Object.values(PrimitiveType).map((type) => (
            <PrimitiveButton key={type} type={type} onClick={() => onAddObject(type)} />
          ))}
        </div>
      </div>
      <div className="p-4 flex-grow overflow-y-auto">
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Scene Hierarchy</h2>
        <ul className="space-y-1">
          {objects.map((obj) => (
            <li
              key={obj.id}
              onClick={() => onSelectObject(obj.id)}
              className={`px-3 py-2 rounded-md text-sm cursor-pointer transition-colors ${
                selectedObjectId === obj.id
                  ? 'bg-sky-600 text-white font-semibold'
                  : 'text-gray-300 hover:bg-gray-800'
              }`}
            >
              {obj.name}
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
};

export default Sidebar;
