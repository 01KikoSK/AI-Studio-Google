
import React from 'react';
import { MoveIcon, RotateIcon, ScaleIcon, UploadIcon, DownloadIcon } from './icons';

type TransformMode = 'translate' | 'rotate' | 'scale';

interface ToolbarProps {
  transformMode: TransformMode;
  setTransformMode: (mode: TransformMode) => void;
  onImport: () => void;
  onExport: () => void;
}

const ToolButton: React.FC<{
  label: string;
  isActive: boolean;
  onClick: () => void;
  children: React.ReactNode;
}> = ({ label, isActive, onClick, children }) => (
  <button
    onClick={onClick}
    title={label}
    className={`p-2 rounded-md ${
      isActive ? 'bg-sky-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
    } transition-colors duration-150`}
  >
    {children}
  </button>
);

const Toolbar: React.FC<ToolbarProps> = ({ transformMode, setTransformMode, onImport, onExport }) => {
  return (
    <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10 bg-gray-800/50 backdrop-blur-sm p-2 rounded-lg shadow-lg border border-gray-700">
      <div className="flex items-center space-x-2">
        <ToolButton
          label="Move (W)"
          isActive={transformMode === 'translate'}
          onClick={() => setTransformMode('translate')}
        >
          <MoveIcon className="w-5 h-5" />
        </ToolButton>
        <ToolButton
          label="Rotate (E)"
          isActive={transformMode === 'rotate'}
          onClick={() => setTransformMode('rotate')}
        >
          <RotateIcon className="w-5 h-5" />
        </ToolButton>
        <ToolButton
          label="Scale (R)"
          isActive={transformMode === 'scale'}
          onClick={() => setTransformMode('scale')}
        >
          <ScaleIcon className="w-5 h-5" />
        </ToolButton>

        <div className="w-px h-6 bg-gray-600 mx-2"></div>

        <ToolButton label="Import Scene" isActive={false} onClick={onImport}>
            <UploadIcon className="w-5 h-5" />
        </ToolButton>
        <ToolButton label="Export Scene" isActive={false} onClick={onExport}>
            <DownloadIcon className="w-5 h-5" />
        </ToolButton>
      </div>
    </div>
  );
};

export default Toolbar;
