
import React from 'react';
import type { LookupHistoryItem } from '../types';

interface HistoryPanelProps {
  history: LookupHistoryItem[];
  onHistoryClick: (item: LookupHistoryItem) => void;
  onClearHistory: () => void;
}

const TimeAgo: React.FC<{ timestamp: number }> = ({ timestamp }) => {
    const now = new Date();
    const secondsAgo = Math.round((now.getTime() - timestamp) / 1000);

    if (secondsAgo < 60) return <span>{secondsAgo}s ago</span>;
    const minutesAgo = Math.floor(secondsAgo / 60);
    if (minutesAgo < 60) return <span>{minutesAgo}m ago</span>;
    const hoursAgo = Math.floor(minutesAgo / 60);
    if (hoursAgo < 24) return <span>{hoursAgo}h ago</span>;
    const daysAgo = Math.floor(hoursAgo / 24);
    return <span>{daysAgo}d ago</span>;
}


export const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, onHistoryClick, onClearHistory }) => {
  return (
    <div className="bg-slate-800/50 p-6 rounded-xl shadow-lg border border-slate-700 h-full">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-slate-200">Recent Lookups</h3>
        {history.length > 0 && (
          <button 
            onClick={onClearHistory}
            className="text-xs text-slate-400 hover:text-red-400 transition-colors"
          >
            Clear All
          </button>
        )}
      </div>
      {history.length === 0 ? (
        <p className="text-sm text-slate-400 text-center py-8">No lookups yet.</p>
      ) : (
        <ul className="space-y-2">
          {history.map((item) => (
            <li key={`${item.domain}-${item.recordType}-${item.timestamp}`}>
              <button
                onClick={() => onHistoryClick(item)}
                className="w-full text-left p-3 rounded-md bg-slate-700/50 hover:bg-slate-700 transition-colors duration-150 group"
              >
                <div className="flex justify-between items-center">
                    <div>
                        <span className="font-semibold text-cyan-400">{item.recordType}</span>
                        <span className="text-slate-300 ml-2 break-all">{item.domain}</span>
                    </div>
                    <span className="text-xs text-slate-400 flex-shrink-0 ml-2">
                        <TimeAgo timestamp={item.timestamp} />
                    </span>
                </div>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
