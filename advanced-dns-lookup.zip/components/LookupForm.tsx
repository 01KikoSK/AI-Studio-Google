
import React, { useState, useEffect } from 'react';
import { DNS_RECORD_TYPES, RECORD_TYPE_DESCRIPTIONS } from '../constants';
import type { RecordType } from '../types';
import { SearchIcon } from './icons/SearchIcon';

interface LookupFormProps {
  onLookup: (domain: string, recordType: RecordType) => void;
  isLoading: boolean;
  initialValues?: { domain: string, recordType: RecordType } | null;
}

export const LookupForm: React.FC<LookupFormProps> = ({ onLookup, isLoading, initialValues }) => {
  const [domain, setDomain] = useState<string>('');
  const [recordType, setRecordType] = useState<RecordType>('A');

  useEffect(() => {
    if(initialValues) {
        setDomain(initialValues.domain);
        setRecordType(initialValues.recordType);
    }
  }, [initialValues]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (domain.trim()) {
      onLookup(domain.trim(), recordType);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-end gap-4">
        <div className="flex-grow">
          <label htmlFor="domain" className="block text-sm font-medium text-slate-300 mb-1">
            Domain Name
          </label>
          <input
            id="domain"
            type="text"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            placeholder="e.g., google.com"
            className="w-full px-4 py-2.5 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors duration-200 text-white placeholder-slate-400"
            required
          />
        </div>
        <div className="w-full sm:w-auto">
          <label htmlFor="recordType" className="block text-sm font-medium text-slate-300 mb-1">
            Record Type
          </label>
          <select
            id="recordType"
            value={recordType}
            onChange={(e) => setRecordType(e.target.value as RecordType)}
            className="w-full px-4 py-2.5 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors duration-200 text-white"
          >
            {DNS_RECORD_TYPES.map((type) => (
              <option key={type} value={type}>
                {type} - {RECORD_TYPE_DESCRIPTIONS[type]}
              </option>
            ))}
          </select>
        </div>
        <div className="w-full sm:w-auto">
            <button
                type="submit"
                disabled={isLoading || !domain.trim()}
                className="w-full flex items-center justify-center px-6 py-2.5 bg-cyan-600 text-white font-semibold rounded-md hover:bg-cyan-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500"
            >
                {isLoading ? (
                <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Querying...
                </>
                ) : (
                <>
                    <SearchIcon className="h-5 w-5 mr-2" />
                    Lookup
                </>
                )}
            </button>
        </div>
      </div>
    </form>
  );
};
