
import React from 'react';
import type { DnsResponse, DnsAnswer } from '../types';

interface ResultsDisplayProps {
  data: DnsResponse;
}

const renderAnswer = (answer: DnsAnswer) => {
    return (
         <tr key={`${answer.name}-${answer.data}-${answer.TTL}`} className="bg-slate-800 hover:bg-slate-700/50 transition-colors duration-150">
            <td className="px-4 py-3 text-sm text-slate-300 break-all">{answer.name}</td>
            <td className="px-4 py-3 text-sm font-mono text-cyan-400">{answer.type}</td>
            <td className="px-4 py-3 text-sm text-slate-300">{answer.TTL}</td>
            <td className="px-4 py-3 text-sm text-slate-200 break-all whitespace-pre-wrap font-mono">{answer.data}</td>
        </tr>
    );
};

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ data }) => {
  const hasAnswers = data.Answer && data.Answer.length > 0;
  const hasAuthority = data.Authority && data.Authority.length > 0;
  
  if (!hasAnswers && !hasAuthority) {
      return (
        <div className="bg-slate-800/50 p-6 rounded-xl shadow-lg border border-slate-700 text-center">
            <h3 className="text-lg font-semibold text-slate-300">No Records Found</h3>
            <p className="text-slate-400 mt-1">
                The DNS query for <span className="font-semibold text-cyan-400">{data.Question[0].name}</span> with type <span className="font-semibold text-cyan-400">{data.Question[0].type}</span> returned no records.
            </p>
             {data.Comment && <p className="text-xs text-slate-500 mt-4 italic">"{data.Comment}"</p>}
        </div>
      );
  }

  return (
    <div className="bg-slate-800/50 p-1 sm:p-2 rounded-xl shadow-lg border border-slate-700">
        <div className="overflow-x-auto">
            <h3 className="text-lg font-semibold text-slate-200 p-4">
                Query Results for <span className="text-cyan-400">{data.Question[0].name}</span>
            </h3>

            {hasAnswers && (
                <>
                <h4 className="px-4 pt-2 pb-1 text-sm font-bold uppercase text-slate-400 tracking-wider">Answer Section</h4>
                <table className="w-full min-w-[600px] text-left">
                    <thead className="bg-slate-900/70">
                        <tr>
                            <th className="px-4 py-2.5 text-xs font-semibold uppercase text-slate-400 tracking-wider">Name</th>
                            <th className="px-4 py-2.5 text-xs font-semibold uppercase text-slate-400 tracking-wider">Type</th>
                            <th className="px-4 py-2.5 text-xs font-semibold uppercase text-slate-400 tracking-wider">TTL</th>
                            <th className="px-4 py-2.5 text-xs font-semibold uppercase text-slate-400 tracking-wider">Data</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700">
                        {data.Answer!.map(renderAnswer)}
                    </tbody>
                </table>
                </>
            )}

            {hasAuthority && (
                <>
                <h4 className="px-4 pt-4 pb-1 text-sm font-bold uppercase text-slate-400 tracking-wider">Authority Section</h4>
                <table className="w-full min-w-[600px] text-left">
                    {!hasAnswers && (
                         <thead className="bg-slate-900/70">
                            <tr>
                                <th className="px-4 py-2.5 text-xs font-semibold uppercase text-slate-400 tracking-wider">Name</th>
                                <th className="px-4 py-2.5 text-xs font-semibold uppercase text-slate-400 tracking-wider">Type</th>
                                <th className="px-4 py-2.5 text-xs font-semibold uppercase text-slate-400 tracking-wider">TTL</th>
                                <th className="px-4 py-2.5 text-xs font-semibold uppercase text-slate-400 tracking-wider">Data</th>
                            </tr>
                        </thead>
                    )}
                    <tbody className="divide-y divide-slate-700">
                        {data.Authority!.map(renderAnswer)}
                    </tbody>
                </table>
                </>
            )}
        </div>
    </div>
  );
};
