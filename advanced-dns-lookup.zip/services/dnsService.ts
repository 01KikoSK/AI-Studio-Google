
import type { DnsResponse, RecordType } from '../types';

const DNS_API_URL = 'https://dns.google/resolve';

export const fetchDnsRecords = async (domain: string, recordType: RecordType): Promise<DnsResponse> => {
  const url = `${DNS_API_URL}?name=${encodeURIComponent(domain)}&type=${recordType}`;

  const response = await fetch(url, {
    headers: {
      'Accept': 'application/dns-json',
    },
  });

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  const data: DnsResponse = await response.json();
  return data;
};
