
export const DNS_RECORD_TYPES = [
  'A',
  'AAAA',
  'CNAME',
  'MX',
  'NS',
  'PTR',
  'SOA',
  'SRV',
  'TXT',
  'ANY'
] as const;

export const RECORD_TYPE_DESCRIPTIONS: { [key: string]: string } = {
    A: "IPv4 Address",
    AAAA: "IPv6 Address",
    CNAME: "Canonical Name",
    MX: "Mail Exchange",
    NS: "Name Server",
    PTR: "Pointer Record",
    SOA: "Start of Authority",
    SRV: "Service Record",
    TXT: "Text Record",
    ANY: "Any Record Type",
};
