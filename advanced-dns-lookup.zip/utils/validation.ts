
export const isValidDomain = (domain: string): boolean => {
  if (!domain || domain.length > 253) {
    return false;
  }
  // This is a simplified regex for domain validation.
  // It checks for basic structure but is not fully compliant with all RFCs.
  const domainRegex = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$/i;
  return domainRegex.test(domain);
};
