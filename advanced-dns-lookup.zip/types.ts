
import { DNS_RECORD_TYPES } from './constants';

export type RecordType = typeof DNS_RECORD_TYPES[number];

export interface DnsQuestion {
  name: string;
  type: number;
}

export interface DnsAnswer {
  name: string;
  type: number;
  TTL: number;
  data: string;
}

export interface DnsResponse {
  Status: number; // 0 for success (NOERROR)
  TC: boolean;
  RD: boolean;
  RA: boolean;
  AD: boolean;
  CD: boolean;
  Question: DnsQuestion[];
  Answer?: DnsAnswer[];
  Authority?: DnsAnswer[];
  Comment?: string;
}

export interface LookupHistoryItem {
  domain: string;
  recordType: RecordType;
  timestamp: number;
}
