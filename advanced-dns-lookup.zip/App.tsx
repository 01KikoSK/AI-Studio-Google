
import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { LookupForm } from './components/LookupForm';
import { ResultsDisplay } from './components/ResultsDisplay';
import { LoadingSpinner } from './components/LoadingSpinner';
import { HistoryPanel } from './components/HistoryPanel';
import { ErrorMessage } from './components/ErrorMessage';
import { fetchDnsRecords } from './services/dnsService';
import type { DnsResponse, LookupHistoryItem, RecordType } from './types';
import { isValidDomain } from './utils/validation';


const App: React.FC = () => {
    const [results, setResults] = useState<DnsResponse | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [history, setHistory] = useState<LookupHistoryItem[]>([]);
    const [currentLookup, setCurrentLookup] = useState<{domain: string, recordType: RecordType} | null>(null);

    useEffect(() => {
        try {
            const storedHistory = localStorage.getItem('dnsLookupHistory');
            if (storedHistory) {
                setHistory(JSON.parse(storedHistory));
            }
        } catch (e) {
            console.error("Failed to parse history from localStorage", e);
            localStorage.removeItem('dnsLookupHistory');
        }
    }, []);

    const updateHistory = (item: LookupHistoryItem) => {
        setHistory(prevHistory => {
            const newHistory = [item, ...prevHistory.filter(h => !(h.domain === item.domain && h.recordType === item.recordType))].slice(0, 10);
            localStorage.setItem('dnsLookupHistory', JSON.stringify(newHistory));
            return newHistory;
        });
    };

    const handleLookup = useCallback(async (domain: string, recordType: RecordType) => {
        if (!isValidDomain(domain)) {
            setError('Please enter a valid domain name.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setResults(null);
        setCurrentLookup({ domain, recordType });

        try {
            const data = await fetchDnsRecords(domain, recordType);
            if (data.Status !== 0) { // 0 is NOERROR
                 setError(`DNS query failed with status: ${data.Status}. The domain may not exist or has no records of this type.`);
                 setResults(null);
            } else {
                 setResults(data);
                 updateHistory({ domain, recordType, timestamp: Date.now() });
            }
        } catch (err) {
            console.error(err);
            setError('An unexpected network error occurred. Please check your connection and try again.');
            setResults(null);
        } finally {
            setIsLoading(false);
        }
    }, []);
    
    const handleHistoryClick = (item: LookupHistoryItem) => {
        handleLookup(item.domain, item.recordType);
    };
    
    const clearHistory = () => {
        setHistory([]);
        localStorage.removeItem('dnsLookupHistory');
    };

    return (
        <div className="min-h-screen bg-slate-900 text-gray-200 font-sans p-4 sm:p-6 lg:p-8">
            <div className="max-w-7xl mx-auto">
                <Header />
                <main className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2">
                         <div className="bg-slate-800/50 p-6 rounded-xl shadow-2xl border border-slate-700">
                            <LookupForm onLookup={handleLookup} isLoading={isLoading} initialValues={currentLookup} />
                        </div>
                        <div className="mt-8">
                            {isLoading && <LoadingSpinner />}
                            {error && !isLoading && <ErrorMessage message={error} />}
                            {results && !isLoading && <ResultsDisplay data={results} />}
                            {!isLoading && !error && !results && (
                                <div className="text-center py-16 px-6 bg-slate-800/50 rounded-xl border border-slate-700">
                                    <h2 className="text-2xl font-semibold text-slate-300">Welcome to DNS Lookup</h2>
                                    <p className="mt-2 text-slate-400">Enter a domain and select a record type to begin.</p>
                                </div>
                            )}
                        </div>
                    </div>
                    <div className="lg:col-span-1">
                        <HistoryPanel history={history} onHistoryClick={handleHistoryClick} onClearHistory={clearHistory} />
                    </div>
                </main>
            </div>
        </div>
    );
};

export default App;
